
- Add missing return statements in task4.c
- Re-create t4 binary and update/test the solution exploit
