#!/usr/bin/env bash
#
apt update
apt upgrade
apt install -y gcc gdb make build-essential software-properties-common
apt install -y emacs
